#Codigo para obtener secuencia de aminoacidos de archivo y comparar con una cadena de aa para ver si son iguales.
#Nota: la secuencia debe estar en letras mayusculas.

from Bio.PDB.Polypeptide import three_to_one

vector_aa=[]

#Recorre el archivo por lineas y guarda en un vector los aminoacidos
with open("/Users/Bernardo/Desktop/smad2_mh2.txt") as f:
    for line in f:
        if " CA " in line:
            columns = line.split()
            vector_aa.append(columns[3])

#Cambiando la selenometionina (SME) a metionina (MET)
for x in range(0, len(vector_aa)):
    if (vector_aa[x]=="MSE"):
        vector_aa[x]="MET"

#Cambiando la serina fosforilada (SEP) a serina (SER)
for x in range(0, len(vector_aa)):
    if (vector_aa[x]=="SEP"):
        vector_aa[x]="SER"

vector_secuencia= list("LDLQPVTYSEPAFWCSIAYYELNQRVGETFHASQPSLTVDGFTDPSNSERFCLGLLSNVNRNATVEMTRRHIGRGVRLYYIGGEVFAECLSDSAIFVQSPNCNQRYGWHPATVCKIPPGCNLKIFNNQEFAALLAQSVNQGFEAVYQLTRMCTIRMSFVKGWGRQTVTSTPCWIELHLNGPLQWLDKVLTQM")


#Convierte el codigo de 3 letras a una letra del vector_aa.
for x in range(0, len(vector_aa)):
    vector_aa[x]=three_to_one(vector_aa[x])

#Compara ambas listas para ver si las secuencias son iguales o no.
if vector_aa==vector_secuencia:
    print ("Son iguales")
else:
    print ("No son iguales")