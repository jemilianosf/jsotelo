res<-read.table('./results.tab')
fig<-read.table('./fig.tab')

#Grafica de E1 contra E2
firstseq<-fig[2:239,]

firstseq$V1<-as.numeric(levels(firstseq$V1))[firstseq$V1]#convertir los factores a numericos
firstseq$V3<-as.numeric(levels(firstseq$V3))[firstseq$V3]
firstseq$V4<-as.numeric(levels(firstseq$V4))[firstseq$V4]

plot(x=firstseq$V1,y=firstseq$V3, type='l', col='grey', ylab="dG", xlab="n")
lines(x=firstseq$V1,y=firstseq$V4, col='turquoise')


#Grafica de E1 contra E2
ocurrences<-res$V1[-which(res$V1=='sequence')]#Quitar los renglones de informacion de secuencia
ocurrences<-as.numeric(levels(ocurrences))[ocurrences]
hist(ocurrences)

